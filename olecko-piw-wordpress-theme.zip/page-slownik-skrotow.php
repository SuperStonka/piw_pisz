<?php get_header(); ?>

<main id="main" class="site-main" role="main">
    <div class="content-area full-width">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                </header>

                <div class="entry-content">
                    <section aria-labelledby="abbreviations-intro">
                        <h2 id="abbreviations-intro"><?php _e('Wprowadzenie', 'olecko-piw'); ?></h2>
                        <p><?php _e('Poniżej znajduje się słownik skrótów i akronimów używanych na stronie internetowej Powiatowego Inspektoratu Weterynaryjnego w Olecku.', 'olecko-piw'); ?></p>
                    </section>

                    <section aria-labelledby="abbreviations-list">
                        <h2 id="abbreviations-list"><?php _e('Lista skrótów', 'olecko-piw'); ?></h2>
                        <dl class="abbreviations-dictionary">
                            <dt><abbr title="Powiatowy Inspektorat Weterynaryjny">PIW</abbr></dt>
                            <dd><?php _e('Powiatowy Inspektorat Weterynaryjny', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Afrykański Pomór Świń">ASF</abbr></dt>
                            <dd><?php _e('Afrykański Pomór Świń (African Swine Fever)', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Biuletyn Informacji Publicznej">BIP</abbr></dt>
                            <dd><?php _e('Biuletyn Informacji Publicznej', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Unia Europejska">UE</abbr></dt>
                            <dd><?php _e('Unia Europejska', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Główny Inspektorat Weterynarii">GIW</abbr></dt>
                            <dd><?php _e('Główny Inspektorat Weterynarii', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Powiatowy Lekarz Weterynarii">PLW</abbr></dt>
                            <dd><?php _e('Powiatowy Lekarz Weterynarii', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Rozporządzenie">Rozp.</abbr></dt>
                            <dd><?php _e('Rozporządzenie', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Ustawa">Ust.</abbr></dt>
                            <dd><?php _e('Ustawa', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Dziennik Ustaw">Dz.U.</abbr></dt>
                            <dd><?php _e('Dziennik Ustaw', 'olecko-piw'); ?></dd>
                            
                            <dt><abbr title="Web Content Accessibility Guidelines">WCAG</abbr></dt>
                            <dd><?php _e('Web Content Accessibility Guidelines - Wytyczne dostępności treści internetowych', 'olecko-piw'); ?></dd>
                        </dl>
                    </section>

                    <section aria-labelledby="medical-terms">
                        <h2 id="medical-terms"><?php _e('Terminy weterynaryjne', 'olecko-piw'); ?></h2>
                        <dl class="medical-dictionary">
                            <dt><?php _e('Biosekurność', 'olecko-piw'); ?></dt>
                            <dd><?php _e('Zespół środków organizacyjnych, technicznych i sanitarnych mających na celu ochronę przed wprowadzeniem i rozprzestrzenianiem się chorób zakaźnych zwierząt.', 'olecko-piw'); ?></dd>
                            
                            <dt><?php _e('Epizoocja', 'olecko-piw'); ?></dt>
                            <dd><?php _e('Masowe występowanie choroby zakaźnej zwierząt na określonym obszarze.', 'olecko-piw'); ?></dd>
                            
                            <dt><?php _e('Kwarantanna', 'olecko-piw'); ?></dt>
                            <dd><?php _e('Izolacja zwierząt podejrzanych o zakażenie w celu zapobieżenia rozprzestrzenianiu się choroby.', 'olecko-piw'); ?></dd>
                        </dl>
                    </section>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
</main>

<style>
.abbreviations-dictionary,
.medical-dictionary {
    margin: 20px 0;
}

.abbreviations-dictionary dt,
.medical-dictionary dt {
    font-weight: bold;
    color: #d32f2f;
    margin-top: 15px;
    margin-bottom: 5px;
}

.abbreviations-dictionary dd,
.medical-dictionary dd {
    margin-left: 20px;
    margin-bottom: 10px;
    line-height: 1.6;
}

abbr {
    text-decoration: underline dotted;
    cursor: help;
}
</style>

<?php get_footer(); ?>
