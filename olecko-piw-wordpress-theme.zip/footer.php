<footer class="site-footer" role="contentinfo">
    <div class="footer-content">
        <div class="footer-section">
            <h3><?php _e('Główny redaktor Biuletynu', 'olecko-piw'); ?></h3>
            <p><?php _e('Powiatowy Lekarz Weterynarii w Olecku', 'olecko-piw'); ?></p>
            <p><?php _e('ul. Leśna 40', 'olecko-piw'); ?></p>
            <p><?php _e('19-400 Olecko', 'olecko-piw'); ?></p>
        </div>
        
        <div class="footer-section">
            <h3><?php _e('Adres redakcji Biuletynu', 'olecko-piw'); ?></h3>
            <p><?php _e('Powiatowy Inspektorat Weterynaryjny w Olecku', 'olecko-piw'); ?></p>
            <p><?php _e('ul. Leśna 40', 'olecko-piw'); ?></p>
            <p><?php _e('19-400 Olecko', 'olecko-piw'); ?></p>
        </div>
        
        <div class="footer-section">
            <h3><?php _e('Informacje o serwisie', 'olecko-piw'); ?></h3>
            <p><a href="mailto:<?php echo antispambot('olecko@piw.gov.pl'); ?>">olecko@piw.gov.pl</a></p>
            <p><?php _e('Telefon: 87 520-21-48', 'olecko-piw'); ?></p>
            <p><?php _e('Fax: 87 520-20-59', 'olecko-piw'); ?></p>
        </div>
    </div>
    
    <div class="footer-bottom">
        <p>&copy; <?php echo date('Y'); ?> <?php _e('Powiatowy Inspektorat Weterynaryjny w Olecku', 'olecko-piw'); ?></p>
        <p><?php _e('Wszystkie prawa zastrzeżone', 'olecko-piw'); ?></p>
    </div>
</footer>

<?php wp_footer(); ?>

<script>
// Accessibility features
document.addEventListener('DOMContentLoaded', function() {
    // High contrast toggle
    const contrastToggle = document.getElementById('toggle-contrast');
    const textOnlyToggle = document.getElementById('toggle-text-only');
    const fontSmallerBtn = document.getElementById('font-smaller');
    const fontNormalBtn = document.getElementById('font-normal');
    const fontLargerBtn = document.getElementById('font-larger');
    
    // Load saved preferences
    if (localStorage.getItem('high-contrast') === 'true') {
        document.body.classList.add('high-contrast');
        contrastToggle.setAttribute('aria-pressed', 'true');
    }
    
    if (localStorage.getItem('text-only') === 'true') {
        document.body.classList.add('text-only');
        textOnlyToggle.setAttribute('aria-pressed', 'true');
    }
    
    const savedFontSize = localStorage.getItem('font-size');
    if (savedFontSize) {
        document.body.style.fontSize = savedFontSize;
    }
    
    // High contrast toggle
    contrastToggle.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.classList.toggle('high-contrast');
        const isPressed = document.body.classList.contains('high-contrast');
        this.setAttribute('aria-pressed', isPressed);
        localStorage.setItem('high-contrast', isPressed);
    });
    
    // Text-only toggle
    textOnlyToggle.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.classList.toggle('text-only');
        const isPressed = document.body.classList.contains('text-only');
        this.setAttribute('aria-pressed', isPressed);
        localStorage.setItem('text-only', isPressed);
    });
    
    // Font size controls
    fontSmallerBtn.addEventListener('click', function() {
        document.body.style.fontSize = '12px';
        localStorage.setItem('font-size', '12px');
    });
    
    fontNormalBtn.addEventListener('click', function() {
        document.body.style.fontSize = '14px';
        localStorage.setItem('font-size', '14px');
    });
    
    fontLargerBtn.addEventListener('click', function() {
        document.body.style.fontSize = '18px';
        localStorage.setItem('font-size', '18px');
    });
    
    // Keyboard navigation enhancement
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Tab') {
            document.body.classList.add('keyboard-navigation');
        }
    });
    
    document.addEventListener('mousedown', function() {
        document.body.classList.remove('keyboard-navigation');
    });
});
</script>

</body>
</html>
