<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main"><?php _e('Przejdź do treści głównej', 'olecko-piw'); ?></a>

<!-- Accessibility Toolbar -->
<div class="accessibility-toolbar" role="banner">
    <div class="container">
        <nav class="accessibility-links" aria-label="<?php _e('Narzędzia dostępności', 'olecko-piw'); ?>">
            <a href="#" id="toggle-contrast" aria-pressed="false">
                <span class="sr-only"><?php _e('Przełącz na', 'olecko-piw'); ?> </span>
                <?php _e('Wersja kontrastowa', 'olecko-piw'); ?>
            </a>
            <a href="#" id="toggle-text-only" aria-pressed="false">
                <span class="sr-only"><?php _e('Przełącz na', 'olecko-piw'); ?> </span>
                <?php _e('Wersja tekstowa', 'olecko-piw'); ?>
            </a>
            <a href="<?php echo esc_url(home_url('/deklaracja-dostepnosci')); ?>">
                <?php _e('Deklaracja dostępności', 'olecko-piw'); ?>
            </a>
            <a href="<?php echo esc_url(home_url('/slownik-skrotow')); ?>">
                <?php _e('Słownik skrótów', 'olecko-piw'); ?>
            </a>
        </nav>
        
        <div class="font-size-controls">
            <span><?php _e('Rozmiar czcionki:', 'olecko-piw'); ?></span>
            <button class="font-size-btn" id="font-smaller" aria-label="<?php _e('Zmniejsz czcionkę', 'olecko-piw'); ?>">A-</button>
            <button class="font-size-btn" id="font-normal" aria-label="<?php _e('Normalna czcionka', 'olecko-piw'); ?>">A</button>
            <button class="font-size-btn" id="font-larger" aria-label="<?php _e('Zwiększ czcionkę', 'olecko-piw'); ?>">A+</button>
        </div>
    </div>
</div>

<header class="site-header" role="banner">
    <div class="header-top">
        <div class="header-content">
            <div class="site-logo">
                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-piw.png" 
                         alt="<?php _e('Logo Powiatowego Inspektoratu Weterynaryjnego', 'olecko-piw'); ?>">
                </a>
            </div>
            
            <div class="site-title">
                <h1>
                    <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                        <?php _e('Powiatowy Inspektorat Weterynaryjny w Olecku', 'olecko-piw'); ?>
                    </a>
                </h1>
            </div>
            
            <div class="eu-logos">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-eu.png" 
                     alt="<?php _e('Logo Unii Europejskiej', 'olecko-piw'); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/assets/images/logo-poland.png" 
                     alt="<?php _e('Godło Polski', 'olecko-piw'); ?>">
            </div>
        </div>
    </div>
    
    <nav class="main-navigation" role="navigation" aria-label="<?php _e('Menu główne', 'olecko-piw'); ?>">
        <div class="nav-container">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class' => 'main-menu',
                'container' => false,
                'fallback_cb' => 'olecko_piw_default_menu'
            ));
            ?>
        </div>
    </nav>
</header>
