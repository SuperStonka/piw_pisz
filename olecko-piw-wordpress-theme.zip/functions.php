<?php
/**
 * Olecko PIW Theme functions and definitions
 */

// Theme setup
function olecko_piw_setup() {
    // Add theme support for various features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Menu główne', 'olecko-piw'),
        'sidebar-menu' => __('Menu boczne', 'olecko-piw'),
    ));
    
    // Load text domain for translations
    load_theme_textdomain('olecko-piw', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'olecko_piw_setup');

// Enqueue styles and scripts
function olecko_piw_scripts() {
    wp_enqueue_style('olecko-piw-style', get_stylesheet_uri(), array(), '1.0.0');
    
    // Add accessibility script
    wp_enqueue_script('olecko-piw-accessibility', get_template_directory_uri() . '/js/accessibility.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'olecko_piw_scripts');

// Default menu fallback
function olecko_piw_default_menu() {
    echo '<ul class="main-menu">';
    echo '<li><a href="' . esc_url(home_url('/')) . '">' . __('Strona główna', 'olecko-piw') . '</a></li>';
    echo '<li><a href="' . esc_url(home_url('/o-nas')) . '">' . __('O nas', 'olecko-piw') . '</a></li>';
    echo '<li><a href="' . esc_url(home_url('/kontakt')) . '">' . __('Kontakt', 'olecko-piw') . '</a></li>';
    echo '</ul>';
}

// Default sidebar menu fallback
function olecko_piw_default_sidebar_menu() {
    echo '<ul class="sidebar-menu">';
    echo '<li><a href="' . esc_url(home_url('/struktura-organizacyjna')) . '">' . __('Struktura organizacyjna', 'olecko-piw') . '</a></li>';
    echo '<li><a href="' . esc_url(home_url('/informacje-finansowe')) . '">' . __('Informacje finansowe', 'olecko-piw') . '</a></li>';
    echo '<li><a href="' . esc_url(home_url('/plan-urzedowej-kontroli')) . '">' . __('Plan urzędowej kontroli', 'olecko-piw') . '</a></li>';
    echo '<li><a href="' . esc_url(home_url('/kontrole-urzedowe')) . '">' . __('Kontrole urzędowe', 'olecko-piw') . '</a></li>';
    echo '</ul>';
}

// Add accessibility features to WordPress
function olecko_piw_accessibility_features() {
    // Add lang attribute to HTML tag
    add_filter('language_attributes', function($output) {
        return $output . ' lang="pl"';
    });
    
    // Enhance image alt text
    add_filter('wp_get_attachment_image_attributes', function($attr, $attachment) {
        if (empty($attr['alt'])) {
            $attr['alt'] = get_the_title($attachment->ID);
        }
        return $attr;
    }, 10, 2);
}
add_action('init', 'olecko_piw_accessibility_features');

// Create accessibility pages
function olecko_piw_create_accessibility_pages() {
    // Accessibility Declaration page
    $accessibility_page = array(
        'post_title' => 'Deklaracja dostępności',
        'post_content' => 'Powiatowy Inspektorat Weterynaryjny w Olecku zobowiązuje się zapewnić dostępność swojej strony internetowej zgodnie z ustawą z dnia 4 kwietnia 2019 r. o dostępności cyfrowej stron internetowych i aplikacji mobilnych podmiotów publicznych.',
        'post_status' => 'publish',
        'post_type' => 'page',
        'post_name' => 'deklaracja-dostepnosci'
    );
    
    if (!get_page_by_path('deklaracja-dostepnosci')) {
        wp_insert_post($accessibility_page);
    }
    
    // Abbreviations Dictionary page
    $dictionary_page = array(
        'post_title' => 'Słownik skrótów',
        'post_content' => '<h2>Słownik skrótów używanych na stronie</h2>
        <dl>
        <dt>PIW</dt><dd>Powiatowy Inspektorat Weterynaryjny</dd>
        <dt>ASF</dt><dd>Afrykański Pomór Świń</dd>
        <dt>BIP</dt><dd>Biuletyn Informacji Publicznej</dd>
        <dt>UE</dt><dd>Unia Europejska</dd>
        </dl>',
        'post_status' => 'publish',
        'post_type' => 'page',
        'post_name' => 'slownik-skrotow'
    );
    
    if (!get_page_by_path('slownik-skrotow')) {
        wp_insert_post($dictionary_page);
    }
}
add_action('after_switch_theme', 'olecko_piw_create_accessibility_pages');

// Add WCAG compliance features
function olecko_piw_wcag_compliance() {
    // Add skip links
    add_action('wp_body_open', function() {
        echo '<a class="skip-link screen-reader-text" href="#main">' . __('Przejdź do treści głównej', 'olecko-piw') . '</a>';
    });
    
    // Ensure proper heading hierarchy
    add_filter('the_content', function($content) {
        // This would need more sophisticated logic in a real implementation
        return $content;
    });
}
add_action('init', 'olecko_piw_wcag_compliance');

// Add structured data for better SEO and accessibility
function olecko_piw_structured_data() {
    if (is_front_page()) {
        $structured_data = array(
            '@context' => 'https://schema.org',
            '@type' => 'GovernmentOrganization',
            'name' => 'Powiatowy Inspektorat Weterynaryjny w Olecku',
            'url' => home_url(),
            'address' => array(
                '@type' => 'PostalAddress',
                'streetAddress' => 'ul. Leśna 40',
                'addressLocality' => 'Olecko',
                'postalCode' => '19-400',
                'addressCountry' => 'PL'
            ),
            'telephone' => '87 520-21-48',
            'email' => 'olecko@piw.gov.pl'
        );
        
        echo '<script type="application/ld+json">' . json_encode($structured_data) . '</script>';
    }
}
add_action('wp_head', 'olecko_piw_structured_data');
?>
