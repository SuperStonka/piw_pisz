<?php get_header(); ?>

<main id="main" class="site-main" role="main">
    <div class="content-area full-width">
        <?php while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <h1 class="entry-title"><?php the_title(); ?></h1>
                </header>

                <div class="entry-content">
                    <section aria-labelledby="declaration-intro">
                        <h2 id="declaration-intro"><?php _e('Wprowadzenie', 'olecko-piw'); ?></h2>
                        <p><?php _e('Powiatowy Inspektorat Weterynaryjny w Olecku zobowiązuje się zapewnić dostępność swojej strony internetowej zgodnie z ustawą z dnia 4 kwietnia 2019 r. o dostępności cyfrowej stron internetowych i aplikacji mobilnych podmiotów publicznych.', 'olecko-piw'); ?></p>
                    </section>

                    <section aria-labelledby="compliance-status">
                        <h2 id="compliance-status"><?php _e('Stan zgodności', 'olecko-piw'); ?></h2>
                        <p><?php _e('Ta strona internetowa jest częściowo zgodna z ustawą z dnia 4 kwietnia 2019 r. o dostępności cyfrowej stron internetowych i aplikacji mobilnych podmiotów publicznych ze względu na niezgodności wymienione poniżej.', 'olecko-piw'); ?></p>
                    </section>

                    <section aria-labelledby="accessibility-features">
                        <h2 id="accessibility-features"><?php _e('Funkcje dostępności', 'olecko-piw'); ?></h2>
                        <ul>
                            <li><?php _e('Wersja kontrastowa - wysoki kontrast dla osób słabowidzących', 'olecko-piw'); ?></li>
                            <li><?php _e('Wersja tekstowa - uproszczona wersja bez grafik', 'olecko-piw'); ?></li>
                            <li><?php _e('Regulacja rozmiaru czcionki', 'olecko-piw'); ?></li>
                            <li><?php _e('Nawigacja klawiaturą', 'olecko-piw'); ?></li>
                            <li><?php _e('Alternatywne opisy obrazów', 'olecko-piw'); ?></li>
                            <li><?php _e('Semantyczna struktura HTML', 'olecko-piw'); ?></li>
                            <li><?php _e('Słownik skrótów', 'olecko-piw'); ?></li>
                        </ul>
                    </section>

                    <section aria-labelledby="contact-accessibility">
                        <h2 id="contact-accessibility"><?php _e('Kontakt w sprawie dostępności', 'olecko-piw'); ?></h2>
                        <p><?php _e('W przypadku problemów z dostępnością strony internetowej prosimy o kontakt:', 'olecko-piw'); ?></p>
                        <address>
                            <p><strong><?php _e('Email:', 'olecko-piw'); ?></strong> <a href="mailto:<?php echo antispambot('olecko@piw.gov.pl'); ?>">olecko@piw.gov.pl</a></p>
                            <p><strong><?php _e('Telefon:', 'olecko-piw'); ?></strong> 87 520-21-48</p>
                            <p><strong><?php _e('Adres:', 'olecko-piw'); ?></strong><br>
                            Powiatowy Inspektorat Weterynaryjny w Olecku<br>
                            ul. Leśna 40<br>
                            19-400 Olecko</p>
                        </address>
                    </section>

                    <section aria-labelledby="date-info">
                        <h2 id="date-info"><?php _e('Informacje o dacie', 'olecko-piw'); ?></h2>
                        <p><?php _e('Deklaracja sporządzona dnia:', 'olecko-piw'); ?> <time datetime="<?php echo date('Y-m-d'); ?>"><?php echo date('d.m.Y'); ?></time></p>
                        <p><?php _e('Deklaracja ostatnio zaktualizowana dnia:', 'olecko-piw'); ?> <time datetime="<?php echo date('Y-m-d'); ?>"><?php echo date('d.m.Y'); ?></time></p>
                    </section>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
</main>

<?php get_footer(); ?>
