<?php get_header(); ?>

<main id="main" class="site-main" role="main">
    <aside class="sidebar" role="complementary">
        <div class="sidebar-widget">
            <h2 class="sidebar-title"><?php _e('Dane podstawowe', 'olecko-piw'); ?></h2>
            <div class="sidebar-content">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'sidebar-menu',
                    'menu_class' => 'sidebar-menu',
                    'container' => false,
                    'fallback_cb' => 'olecko_piw_default_sidebar_menu'
                ));
                ?>
            </div>
        </div>
        
        <div class="sidebar-widget">
            <h2 class="sidebar-title"><?php _e('Informacja', 'olecko-piw'); ?></h2>
            <div class="sidebar-content">
                <div class="info-links">
                    <a href="<?php echo esc_url(home_url('/bip')); ?>" class="bip-link">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/bip-logo.png" alt="<?php _e('Biuletyn Informacji Publicznej', 'olecko-piw'); ?>">
                    </a>
                </div>
            </div>
        </div>
    </aside>

    <div class="content-area">
        <?php if (have_posts()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <header class="entry-header">
                        <h1 class="entry-title"><?php the_title(); ?></h1>
                    </header>

                    <div class="entry-content">
                        <?php the_content(); ?>
                        
                        <!-- Disease Information Section -->
                        <section class="content-section" aria-labelledby="disease-info">
                            <h2 id="disease-info" class="section-title"><?php _e('Informacje o chorobach', 'olecko-piw'); ?></h2>
                            <div class="disease-alert">
                                <h3><?php _e('CHOROBA', 'olecko-piw'); ?></h3>
                                <p><?php _e('Afrykański pomór świń (ASF) to zakaźna choroba wirusowa świń domowych i dzików, która nie stanowi zagrożenia dla ludzi, ale powoduje ogromne straty ekonomiczne w hodowli świń.', 'olecko-piw'); ?></p>
                            </div>
                        </section>

                        <!-- Statistics Section -->
                        <section class="content-section" aria-labelledby="statistics">
                            <h2 id="statistics" class="section-title"><?php _e('Statystyki', 'olecko-piw'); ?></h2>
                            <div class="info-cards">
                                <div class="info-card">
                                    <span class="number">1</span>
                                    <h3><?php _e('TRANSMISJA', 'olecko-piw'); ?></h3>
                                    <p><?php _e('Przenoszenie wirusa między zwierzętami', 'olecko-piw'); ?></p>
                                </div>
                                <div class="info-card">
                                    <span class="number">2</span>
                                    <h3><?php _e('ZAPOBIEGANIE', 'olecko-piw'); ?></h3>
                                    <p><?php _e('Środki prewencyjne i biosekurność', 'olecko-piw'); ?></p>
                                </div>
                                <div class="info-card">
                                    <span class="number">3</span>
                                    <h3><?php _e('ŚWIADOMOŚĆ', 'olecko-piw'); ?></h3>
                                    <p><?php _e('Edukacja i informowanie społeczeństwa', 'olecko-piw'); ?></p>
                                </div>
                            </div>
                        </section>

                        <!-- Important Notices -->
                        <section class="content-section" aria-labelledby="notices">
                            <h2 id="notices" class="section-title"><?php _e('Ważne informacje', 'olecko-piw'); ?></h2>
                            <div class="notice-grid">
                                <div class="notice-item urgent">
                                    <h3><?php _e('PAMIĘTAJ !!!', 'olecko-piw'); ?></h3>
                                    <p><?php _e('Zgłaszaj każde podejrzenie choroby zwierząt do najbliższego lekarza weterynarii.', 'olecko-piw'); ?></p>
                                </div>
                                <div class="notice-item warning">
                                    <h3><?php _e('STOSUJ ZAKAZY !!!', 'olecko-piw'); ?></h3>
                                    <p><?php _e('Przestrzegaj wszystkich zaleceń weterynaryjnych dotyczących biosekurności.', 'olecko-piw'); ?></p>
                                </div>
                            </div>
                        </section>
                    </div>
                </article>
            <?php endwhile; ?>
        <?php else : ?>
            <p><?php _e('Brak treści do wyświetlenia.', 'olecko-piw'); ?></p>
        <?php endif; ?>
    </div>
</main>

<?php get_footer(); ?>
