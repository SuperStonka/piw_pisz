"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface Article {
  id: number
  title: string
  slug: string
  content: string
  excerpt: string
  status: string
  menu_category: string
  responsible_person: string
  author_name: string
  created_at: string
  updated_at: string
  view_count: number
}

interface Version {
  id: number
  version_number: number
  title: string
  content: string
  excerpt: string
  updated_by_name: string
  change_summary: string
  created_at: string
}

export default function EditArticlePage() {
  const router = useRouter()
  const params = useParams()
  const [article, setArticle] = useState<Article | null>(null)
  const [versions, setVersions] = useState<Version[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showVersions, setShowVersions] = useState(false)
  const [selectedVersions, setSelectedVersions] = useState<number[]>([])
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    content: "",
    excerpt: "",
    status: "draft",
    menu_category: "",
    responsible_person: "",
    change_summary: "",
  })

  const menuCategories = [
    "Dane podstawowe",
    "Informacje i komunikaty",
    "Struktura organizacyjna",
    "Sprawozdania finansowe",
    "Plan urzędowej kontroli",
    "Kontrola zarządca",
    "Zamówienia publiczne",
    "Ogłoszenia o naborze",
    "Ogłoszenia inne",
    "RODO",
    "Wzory Dokumentów",
    "Zgłoszenie padnięcia zwierzęcia - formularz online",
    "Zgłoszenie naruszeń prawa",
    "Elektroniczna Skrzynka Podawcza",
    "WYZNACZENIA",
  ]

  useEffect(() => {
    if (params.id) {
      fetchArticle()
      fetchVersions()
    }
  }, [params.id])

  const fetchArticle = async () => {
    try {
      const response = await fetch(`/api/admin/articles/${params.id}`)
      if (response.ok) {
        const data = await response.json()
        setArticle(data)
        setFormData({
          title: data.title,
          slug: data.slug,
          content: data.content,
          excerpt: data.excerpt || "",
          status: data.status,
          menu_category: data.menu_category || "",
          responsible_person: data.responsible_person || "",
          change_summary: "",
        })
      }
    } catch (error) {
      console.error("Error fetching article:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchVersions = async () => {
    try {
      const response = await fetch(`/api/admin/articles/${params.id}/versions`)
      if (response.ok) {
        const data = await response.json()
        setVersions(data)
      }
    } catch (error) {
      console.error("Error fetching versions:", error)
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    // Auto-generate slug from title
    if (name === "title") {
      const slug = value
        .toLowerCase()
        .replace(/ą/g, "a")
        .replace(/ć/g, "c")
        .replace(/ę/g, "e")
        .replace(/ł/g, "l")
        .replace(/ń/g, "n")
        .replace(/ó/g, "o")
        .replace(/ś/g, "s")
        .replace(/ź/g, "z")
        .replace(/ż/g, "z")
        .replace(/[^a-z0-9]/g, "-")
        .replace(/-+/g, "-")
        .replace(/^-|-$/g, "")

      setFormData((prev) => ({
        ...prev,
        slug,
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSaving(true)

    try {
      const response = await fetch(`/api/admin/articles/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        router.push("/admin/articles")
      } else {
        alert("Błąd podczas zapisywania artykułu")
      }
    } catch (error) {
      console.error("Error updating article:", error)
      alert("Błąd podczas zapisywania artykułu")
    } finally {
      setSaving(false)
    }
  }

  const handleVersionSelect = (versionNumber: number) => {
    if (selectedVersions.includes(versionNumber)) {
      setSelectedVersions(selectedVersions.filter((v) => v !== versionNumber))
    } else if (selectedVersions.length < 2) {
      setSelectedVersions([...selectedVersions, versionNumber])
    }
  }

  const compareVersions = () => {
    if (selectedVersions.length === 2) {
      // Implement version comparison logic
      alert(`Porównywanie wersji ${selectedVersions[0]} i ${selectedVersions[1]}`)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3]"></div>
      </div>
    )
  }

  if (!article) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Artykuł nie został znaleziony</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-normal text-gray-900">Edytuj artykuł</h1>
          <p className="text-gray-600">
            ID: {article.id} | Utworzony: {new Date(article.created_at).toLocaleDateString("pl-PL")}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setShowVersions(!showVersions)} className="rounded-none">
            {showVersions ? "Ukryj wersje" : "Pokaż wersje"}
          </Button>
          <Button variant="outline" onClick={() => router.push("/admin/articles")} className="rounded-none">
            Powrót
          </Button>
        </div>
      </div>

      {showVersions && (
        <Card className="rounded-none">
          <CardHeader className="bg-[#2B7CB3] text-white rounded-none">
            <CardTitle className="font-normal">Poprzednie wersje: {article.title}</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="p-3 text-sm text-center bg-yellow-50">
              * każdorazowo możesz wybrać do porównania tylko 2 wersje artykułu
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left">Data aktualizacji</th>
                    <th className="px-4 py-2 text-left">Zaktualizował</th>
                    <th className="px-4 py-2 text-left">Opis zmian</th>
                    <th className="px-4 py-2 text-left">Podgląd treści</th>
                    <th className="px-4 py-2 text-left">Porównaj</th>
                  </tr>
                </thead>
                <tbody>
                  {versions.map((version) => (
                    <tr key={version.id} className="border-b hover:bg-gray-50">
                      <td className="px-4 py-2">{new Date(version.created_at).toLocaleString("pl-PL")}</td>
                      <td className="px-4 py-2">{version.updated_by_name}</td>
                      <td className="px-4 py-2">{version.change_summary}</td>
                      <td className="px-4 py-2">
                        <Button
                          size="sm"
                          variant="outline"
                          className="rounded-none bg-transparent"
                          onClick={() => {
                            // Show version preview
                            alert(`Podgląd wersji ${version.version_number}`)
                          }}
                        >
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5S13.09 3 9.5 3S14 5.91 14 9.5 11.99 14 9.5 14c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
                          </svg>
                        </Button>
                      </td>
                      <td className="px-4 py-2">
                        <input
                          type="checkbox"
                          checked={selectedVersions.includes(version.version_number)}
                          onChange={() => handleVersionSelect(version.version_number)}
                          disabled={!selectedVersions.includes(version.version_number) && selectedVersions.length >= 2}
                          className="rounded"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {selectedVersions.length === 2 && (
              <div className="p-4 border-t">
                <Button onClick={compareVersions} className="bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
                  Porównaj wybrane wersje
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Treść artykułu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Tytuł artykułu</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    required
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="slug">Slug (adres URL)</Label>
                  <Input
                    id="slug"
                    name="slug"
                    value={formData.slug}
                    onChange={handleInputChange}
                    required
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="excerpt">Krótki opis (opcjonalnie)</Label>
                  <Textarea
                    id="excerpt"
                    name="excerpt"
                    value={formData.excerpt}
                    onChange={handleInputChange}
                    rows={3}
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="content">Treść artykułu</Label>
                  <Textarea
                    id="content"
                    name="content"
                    value={formData.content}
                    onChange={handleInputChange}
                    required
                    rows={15}
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="change_summary">Opis wprowadzonych zmian</Label>
                  <Input
                    id="change_summary"
                    name="change_summary"
                    value={formData.change_summary}
                    onChange={handleInputChange}
                    placeholder="Opisz co zostało zmienione w tej wersji"
                    className="rounded-none"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Ustawienia publikacji</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-none bg-white"
                  >
                    <option value="draft">Szkic</option>
                    <option value="published">Opublikowany</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="menu_category">Kategoria menu</Label>
                  <select
                    id="menu_category"
                    name="menu_category"
                    value={formData.menu_category}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-none bg-white"
                  >
                    <option value="">Wybierz kategorię</option>
                    {menuCategories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="responsible_person">Odpowiedzialny za treść</Label>
                  <Input
                    id="responsible_person"
                    name="responsible_person"
                    value={formData.responsible_person}
                    onChange={handleInputChange}
                    className="rounded-none"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="rounded-none mt-6">
              <CardHeader>
                <CardTitle className="font-normal">Statystyki artykułu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Autor:</span>
                  <span>{article.author_name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Wyświetlenia:</span>
                  <span>{article.view_count}</span>
                </div>
                <div className="flex justify-between">
                  <span>Wersji:</span>
                  <span>{versions.length}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ostatnia aktualizacja:</span>
                  <span>{new Date(article.updated_at).toLocaleDateString("pl-PL")}</span>
                </div>
              </CardContent>
            </Card>

            <div className="mt-6 flex gap-3">
              <Button type="submit" disabled={saving} className="flex-1 bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
                {saving ? "Zapisywanie..." : "Zapisz zmiany"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/admin/articles")}
                className="rounded-none"
              >
                Anuluj
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
