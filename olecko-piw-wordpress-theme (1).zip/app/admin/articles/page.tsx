"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface Article {
  id: number
  title: string
  slug: string
  status: string
  menu_category: string
  author_name: string
  created_at: string
  updated_at: string
  view_count: number
}

export default function ArticlesPage() {
  const [articles, setArticles] = useState<Article[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  useEffect(() => {
    fetchArticles()
  }, [])

  const fetchArticles = async () => {
    try {
      const response = await fetch("/api/admin/articles")
      if (response.ok) {
        const data = await response.json()
        setArticles(data)
      }
    } catch (error) {
      console.error("Error fetching articles:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredArticles = articles.filter((article) => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || article.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return <Badge className="bg-green-100 text-green-800 rounded-none">Opublikowany</Badge>
      case "draft":
        return <Badge className="bg-yellow-100 text-yellow-800 rounded-none">Szkic</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800 rounded-none">{status}</Badge>
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3]"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-normal text-gray-900">Artykuły</h1>
          <p className="text-gray-600">Zarządzaj artykułami i treściami strony</p>
        </div>
        <Button className="bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
          <a href="/admin/articles/new">Dodaj nowy artykuł</a>
        </Button>
      </div>

      <Card className="rounded-none">
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <CardTitle className="font-normal">Lista artykułów</CardTitle>
            <div className="flex gap-4">
              <Input
                placeholder="Szukaj artykułów..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64 rounded-none"
              />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-none bg-white"
              >
                <option value="all">Wszystkie statusy</option>
                <option value="published">Opublikowane</option>
                <option value="draft">Szkice</option>
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {filteredArticles.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              {searchTerm || statusFilter !== "all" ? "Brak artykułów spełniających kryteria" : "Brak artykułów"}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Tytuł
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Kategoria
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Autor
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Wyświetlenia
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Data aktualizacji
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                      Akcje
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredArticles.map((article) => (
                    <tr key={article.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="font-normal text-gray-900">{article.title}</div>
                          <div className="text-sm text-gray-500">/{article.slug}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-900">{article.menu_category || "-"}</td>
                      <td className="px-6 py-4">{getStatusBadge(article.status)}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{article.author_name}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">{article.view_count}</td>
                      <td className="px-6 py-4 text-sm text-gray-900">
                        {new Date(article.updated_at).toLocaleDateString("pl-PL")}
                      </td>
                      <td className="px-6 py-4 text-sm font-normal">
                        <div className="flex gap-2">
                          <a
                            href={`/admin/articles/${article.id}/edit`}
                            className="text-[#2B7CB3] hover:text-[#1E5A87]"
                          >
                            Edytuj
                          </a>
                          <a href={`/articles/${article.slug}`} className="text-gray-600 hover:text-gray-900">
                            Podgląd
                          </a>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
