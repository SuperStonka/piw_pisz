"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function NewArticlePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    content: "",
    excerpt: "",
    status: "draft",
    menu_category: "",
    responsible_person: "",
  })

  const menuCategories = [
    "Dane podstawowe",
    "Informacje i komunikaty",
    "Struktura organizacyjna",
    "Sprawozdania finansowe",
    "Plan urzędowej kontroli",
    "Kontrola zarządca",
    "Zamówienia publiczne",
    "Ogłoszenia o naborze",
    "Ogłoszenia inne",
    "RODO",
    "Wzory Dokumentów",
    "Zgłoszenie padnięcia zwierzęcia - formularz online",
    "Zgłoszenie naruszeń prawa",
    "Elektroniczna Skrzynka Podawcza",
    "WYZNACZENIA",
  ]

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    // Auto-generate slug from title
    if (name === "title") {
      const slug = value
        .toLowerCase()
        .replace(/ą/g, "a")
        .replace(/ć/g, "c")
        .replace(/ę/g, "e")
        .replace(/ł/g, "l")
        .replace(/ń/g, "n")
        .replace(/ó/g, "o")
        .replace(/ś/g, "s")
        .replace(/ź/g, "z")
        .replace(/ż/g, "z")
        .replace(/[^a-z0-9]/g, "-")
        .replace(/-+/g, "-")
        .replace(/^-|-$/g, "")

      setFormData((prev) => ({
        ...prev,
        slug,
      }))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/admin/articles", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        router.push("/admin/articles")
      } else {
        alert("Błąd podczas zapisywania artykułu")
      }
    } catch (error) {
      console.error("Error creating article:", error)
      alert("Błąd podczas zapisywania artykułu")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-normal text-gray-900">Nowy artykuł</h1>
        <p className="text-gray-600">Utwórz nowy artykuł dla strony</p>
      </div>

      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Treść artykułu</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Tytuł artykułu</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    required
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="slug">Slug (adres URL)</Label>
                  <Input
                    id="slug"
                    name="slug"
                    value={formData.slug}
                    onChange={handleInputChange}
                    required
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="excerpt">Krótki opis (opcjonalnie)</Label>
                  <Textarea
                    id="excerpt"
                    name="excerpt"
                    value={formData.excerpt}
                    onChange={handleInputChange}
                    rows={3}
                    className="rounded-none"
                  />
                </div>
                <div>
                  <Label htmlFor="content">Treść artykułu</Label>
                  <Textarea
                    id="content"
                    name="content"
                    value={formData.content}
                    onChange={handleInputChange}
                    required
                    rows={15}
                    className="rounded-none"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Ustawienia publikacji</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="status">Status</Label>
                  <select
                    id="status"
                    name="status"
                    value={formData.status}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-none bg-white"
                  >
                    <option value="draft">Szkic</option>
                    <option value="published">Opublikowany</option>
                  </select>
                </div>
                <div>
                  <Label htmlFor="menu_category">Kategoria menu</Label>
                  <select
                    id="menu_category"
                    name="menu_category"
                    value={formData.menu_category}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-none bg-white"
                  >
                    <option value="">Wybierz kategorię</option>
                    {menuCategories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="responsible_person">Odpowiedzialny za treść</Label>
                  <Input
                    id="responsible_person"
                    name="responsible_person"
                    value={formData.responsible_person}
                    onChange={handleInputChange}
                    className="rounded-none"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="mt-6 flex gap-3">
              <Button type="submit" disabled={loading} className="flex-1 bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
                {loading ? "Zapisywanie..." : "Zapisz artykuł"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/admin/articles")}
                className="rounded-none"
              >
                Anuluj
              </Button>
            </div>
          </div>
        </div>
      </form>
    </div>
  )
}
