"use client"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface DashboardStats {
  articleStats: {
    total_articles: number
    published_articles: number
    draft_articles: number
    total_views: number
  }
  recentArticles: Array<{
    title: string
    slug: string
    status: string
    created_at: string
    author_name: string
  }>
}

export default function AdminDashboard() {
  const { data: session } = useSession()
  const [stats, setStats] = useState<DashboardStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboardStats()
  }, [])

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch("/api/admin/analytics")
      if (response.ok) {
        const data = await response.json()
        setStats({
          articleStats: data.articleStats,
          recentArticles: data.recentArticles.slice(0, 5), // Show only 5 recent articles
        })
      }
    } catch (error) {
      console.error("Error fetching dashboard stats:", error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-normal text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Witaj w panelu administracyjnym, {session?.user?.username}!</p>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3]"></div>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="rounded-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-normal text-gray-600">Wszystkie artykuły</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-normal text-gray-900">{stats?.articleStats.total_articles || 0}</div>
              </CardContent>
            </Card>

            <Card className="rounded-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-normal text-gray-600">Opublikowane</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-normal text-gray-900">{stats?.articleStats.published_articles || 0}</div>
              </CardContent>
            </Card>

            <Card className="rounded-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-normal text-gray-600">Szkice</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-normal text-gray-900">{stats?.articleStats.draft_articles || 0}</div>
              </CardContent>
            </Card>

            <Card className="rounded-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-normal text-gray-600">Łączne wyświetlenia</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-normal text-gray-900">{stats?.articleStats.total_views || 0}</div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Ostatnie artykuły</CardTitle>
              </CardHeader>
              <CardContent>
                {stats?.recentArticles && stats.recentArticles.length > 0 ? (
                  <div className="space-y-3">
                    {stats.recentArticles.map((article, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-none">
                        <div>
                          <div className="font-normal text-sm">{article.title}</div>
                          <div className="text-xs text-gray-500">
                            {article.author_name} • {new Date(article.created_at).toLocaleDateString("pl-PL")}
                          </div>
                        </div>
                        <span
                          className={`px-2 py-1 text-xs rounded-none ${
                            article.status === "published"
                              ? "bg-green-100 text-green-800"
                              : "bg-yellow-100 text-yellow-800"
                          }`}
                        >
                          {article.status === "published" ? "Opublikowany" : "Szkic"}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500 text-center py-8">Brak artykułów do wyświetlenia</p>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-none">
              <CardHeader>
                <CardTitle className="font-normal">Szybkie akcje</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <a
                  href="/admin/articles/new"
                  className="block w-full bg-[#2B7CB3] hover:bg-[#1E5A87] text-white text-center py-2 px-4 rounded-none transition-colors"
                >
                  Dodaj nowy artykuł
                </a>
                <a
                  href="/admin/analytics"
                  className="block w-full bg-gray-600 hover:bg-gray-700 text-white text-center py-2 px-4 rounded-none transition-colors"
                >
                  Zobacz analitykę
                </a>
                <a
                  href="/admin/menu"
                  className="block w-full bg-gray-600 hover:bg-gray-700 text-white text-center py-2 px-4 rounded-none transition-colors"
                >
                  Zarządzaj menu
                </a>
                <a
                  href="/admin/settings"
                  className="block w-full bg-gray-600 hover:bg-gray-700 text-white text-center py-2 px-4 rounded-none transition-colors"
                >
                  Ustawienia strony
                </a>
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  )
}
