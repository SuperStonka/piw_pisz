"use client"

import type React from "react"

import { SessionProvider } from "next-auth/react"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

function AdminLayoutContent({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()
  const router = useRouter()

  useEffect(() => {
    if (status === "loading") return // Still loading

    if (!session) {
      router.push("/admin/login")
      return
    }
  }, [session, status, router])

  if (status === "loading") {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3] mx-auto"></div>
          <p className="mt-2 text-gray-600">Ładowanie...</p>
        </div>
      </div>
    )
  }

  if (!session) {
    return null // Will redirect to login
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Header */}
      <header className="bg-[#2B7CB3] text-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-normal">Panel Administracyjny CMS</h1>
              <p className="text-blue-100 text-sm">PIW Pisz</p>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm">
                Zalogowany jako: <strong>{session.user?.username}</strong>
              </span>
              <button
                onClick={() => {
                  // Add sign out functionality
                  window.location.href = "/api/auth/signout"
                }}
                className="bg-[#1E5A87] hover:bg-[#164A73] px-3 py-1 rounded-none text-sm"
              >
                Wyloguj
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Admin Navigation */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            <a href="/admin" className="border-b-2 border-[#2B7CB3] text-[#2B7CB3] py-4 px-1 text-sm font-normal">
              Dashboard
            </a>
            <a
              href="/admin/articles"
              className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 text-sm font-normal"
            >
              Artykuły
            </a>
            <a
              href="/admin/analytics"
              className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 text-sm font-normal"
            >
              Analityka
            </a>
            <a
              href="/admin/menu"
              className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 text-sm font-normal"
            >
              Menu
            </a>
            <a
              href="/admin/settings"
              className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 text-sm font-normal"
            >
              Ustawienia
            </a>
            {session.user?.role === "admin" && (
              <a
                href="/admin/users"
                className="border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300 py-4 px-1 text-sm font-normal"
              >
                Użytkownicy
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">{children}</main>
    </div>
  )
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <AdminLayoutContent>{children}</AdminLayoutContent>
    </SessionProvider>
  )
}
