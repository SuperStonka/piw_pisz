"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface MenuItem {
  id: number
  title: string
  slug: string
  sort_order: number
  is_active: boolean
  created_at: string
  updated_at: string
}

export default function MenuPage() {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([])
  const [loading, setLoading] = useState(true)
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null)
  const [newItem, setNewItem] = useState({ title: "", slug: "" })
  const [draggedItem, setDraggedItem] = useState<MenuItem | null>(null)

  useEffect(() => {
    fetchMenuItems()
  }, [])

  const fetchMenuItems = async () => {
    try {
      const response = await fetch("/api/admin/menu")
      if (response.ok) {
        const data = await response.json()
        setMenuItems(data)
      }
    } catch (error) {
      console.error("Error fetching menu items:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSaveItem = async (item: MenuItem) => {
    try {
      const response = await fetch(`/api/admin/menu/${item.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(item),
      })

      if (response.ok) {
        setEditingItem(null)
        fetchMenuItems()
      }
    } catch (error) {
      console.error("Error updating menu item:", error)
    }
  }

  const handleAddItem = async () => {
    if (!newItem.title) return

    try {
      const response = await fetch("/api/admin/menu", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...newItem,
          sort_order: menuItems.length,
          is_active: true,
        }),
      })

      if (response.ok) {
        setNewItem({ title: "", slug: "" })
        fetchMenuItems()
      }
    } catch (error) {
      console.error("Error adding menu item:", error)
    }
  }

  const handleDeleteItem = async (id: number) => {
    if (!confirm("Czy na pewno chcesz usunąć tę pozycję menu?")) return

    try {
      const response = await fetch(`/api/admin/menu/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        fetchMenuItems()
      }
    } catch (error) {
      console.error("Error deleting menu item:", error)
    }
  }

  const handleToggleActive = async (item: MenuItem) => {
    const updatedItem = { ...item, is_active: !item.is_active }
    await handleSaveItem(updatedItem)
  }

  const handleDragStart = (e: React.DragEvent, item: MenuItem) => {
    setDraggedItem(item)
    e.dataTransfer.effectAllowed = "move"
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    e.dataTransfer.dropEffect = "move"
  }

  const handleDrop = async (e: React.DragEvent, targetItem: MenuItem) => {
    e.preventDefault()

    if (!draggedItem || draggedItem.id === targetItem.id) {
      setDraggedItem(null)
      return
    }

    // Reorder items
    const newItems = [...menuItems]
    const draggedIndex = newItems.findIndex((item) => item.id === draggedItem.id)
    const targetIndex = newItems.findIndex((item) => item.id === targetItem.id)

    // Remove dragged item and insert at target position
    newItems.splice(draggedIndex, 1)
    newItems.splice(targetIndex, 0, draggedItem)

    // Update sort_order for all items
    const updatedItems = newItems.map((item, index) => ({
      ...item,
      sort_order: index,
    }))

    setMenuItems(updatedItems)
    setDraggedItem(null)

    // Save new order to backend
    try {
      await fetch("/api/admin/menu/reorder", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedItems.map((item) => ({ id: item.id, sort_order: item.sort_order }))),
      })
    } catch (error) {
      console.error("Error updating menu order:", error)
      // Revert on error
      fetchMenuItems()
    }
  }

  const moveItem = async (item: MenuItem, direction: "up" | "down") => {
    const currentIndex = menuItems.findIndex((i) => i.id === item.id)
    if ((direction === "up" && currentIndex === 0) || (direction === "down" && currentIndex === menuItems.length - 1)) {
      return
    }

    const newItems = [...menuItems]
    const targetIndex = direction === "up" ? currentIndex - 1 : currentIndex + 1

    // Swap items
    const temp = newItems[currentIndex]
    newItems[currentIndex] = newItems[targetIndex]
    newItems[targetIndex] = temp

    // Update sort_order
    const updatedItems = newItems.map((item, index) => ({
      ...item,
      sort_order: index,
    }))

    setMenuItems(updatedItems)

    // Save to backend
    try {
      await fetch("/api/admin/menu/reorder", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedItems.map((item) => ({ id: item.id, sort_order: item.sort_order }))),
      })
    } catch (error) {
      console.error("Error updating menu order:", error)
      fetchMenuItems()
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3]"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-normal text-gray-900">Zarządzanie menu</h1>
        <p className="text-gray-600">
          Edytuj pozycje menu bocznego strony. Przeciągnij elementy aby zmienić kolejność.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="rounded-none">
          <CardHeader>
            <CardTitle className="font-normal">Dodaj nową pozycję</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="new-title">Nazwa pozycji</Label>
              <Input
                id="new-title"
                value={newItem.title}
                onChange={(e) =>
                  setNewItem((prev) => ({
                    ...prev,
                    title: e.target.value,
                    slug: e.target.value
                      .toLowerCase()
                      .replace(/ą/g, "a")
                      .replace(/ć/g, "c")
                      .replace(/ę/g, "e")
                      .replace(/ł/g, "l")
                      .replace(/ń/g, "n")
                      .replace(/ó/g, "o")
                      .replace(/ś/g, "s")
                      .replace(/ź/g, "z")
                      .replace(/ż/g, "z")
                      .replace(/[^a-z0-9]/g, "-")
                      .replace(/-+/g, "-")
                      .replace(/^-|-$/g, ""),
                  }))
                }
                className="rounded-none"
              />
            </div>
            <div>
              <Label htmlFor="new-slug">Slug</Label>
              <Input
                id="new-slug"
                value={newItem.slug}
                onChange={(e) => setNewItem((prev) => ({ ...prev, slug: e.target.value }))}
                className="rounded-none"
              />
            </div>
            <Button onClick={handleAddItem} className="bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
              Dodaj pozycję
            </Button>
          </CardContent>
        </Card>

        <Card className="rounded-none">
          <CardHeader>
            <CardTitle className="font-normal">Aktualne pozycje menu</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-96 overflow-y-auto">
              {menuItems.map((item, index) => (
                <div
                  key={item.id}
                  className={`border-b border-gray-200 p-4 cursor-move hover:bg-gray-50 ${
                    draggedItem?.id === item.id ? "opacity-50" : ""
                  }`}
                  draggable
                  onDragStart={(e) => handleDragStart(e, item)}
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDrop(e, item)}
                >
                  {editingItem?.id === item.id ? (
                    <div className="space-y-3">
                      <Input
                        value={editingItem.title}
                        onChange={(e) => setEditingItem({ ...editingItem, title: e.target.value })}
                        className="rounded-none"
                      />
                      <Input
                        value={editingItem.slug}
                        onChange={(e) => setEditingItem({ ...editingItem, slug: e.target.value })}
                        className="rounded-none"
                      />
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleSaveItem(editingItem)}
                          className="bg-green-600 hover:bg-green-700 rounded-none"
                        >
                          Zapisz
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingItem(null)}
                          className="rounded-none"
                        >
                          Anuluj
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex flex-col gap-1">
                          <button
                            onClick={() => moveItem(item, "up")}
                            disabled={index === 0}
                            className="text-gray-400 hover:text-gray-600 disabled:opacity-30"
                          >
                            ↑
                          </button>
                          <button
                            onClick={() => moveItem(item, "down")}
                            disabled={index === menuItems.length - 1}
                            className="text-gray-400 hover:text-gray-600 disabled:opacity-30"
                          >
                            ↓
                          </button>
                        </div>
                        <div>
                          <div className="font-normal">{item.title}</div>
                          <div className="text-sm text-gray-500">/{item.slug}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant={item.is_active ? "default" : "outline"}
                          onClick={() => handleToggleActive(item)}
                          className="rounded-none"
                        >
                          {item.is_active ? "Aktywne" : "Nieaktywne"}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setEditingItem(item)}
                          className="rounded-none"
                        >
                          Edytuj
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteItem(item.id)}
                          className="rounded-none"
                        >
                          Usuń
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
