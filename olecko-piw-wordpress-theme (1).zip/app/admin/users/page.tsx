"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useSession } from "next-auth/react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

interface User {
  id: number
  username: string
  email: string
  role: string
  created_at: string
  updated_at: string
}

export default function UsersPage() {
  const { data: session } = useSession()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [showAddForm, setShowAddForm] = useState(false)
  const [newUser, setNewUser] = useState({
    username: "",
    email: "",
    password: "",
    role: "editor",
  })

  useEffect(() => {
    if (session?.user?.role === "admin") {
      fetchUsers()
    }
  }, [session])

  const fetchUsers = async () => {
    try {
      const response = await fetch("/api/admin/users")
      if (response.ok) {
        const data = await response.json()
        setUsers(data)
      }
    } catch (error) {
      console.error("Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newUser),
      })

      if (response.ok) {
        setNewUser({ username: "", email: "", password: "", role: "editor" })
        setShowAddForm(false)
        fetchUsers()
      } else {
        alert("Błąd podczas dodawania użytkownika")
      }
    } catch (error) {
      console.error("Error adding user:", error)
      alert("Błąd podczas dodawania użytkownika")
    }
  }

  const handleDeleteUser = async (id: number) => {
    if (!confirm("Czy na pewno chcesz usunąć tego użytkownika?")) return

    try {
      const response = await fetch(`/api/admin/users/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        fetchUsers()
      } else {
        alert("Błąd podczas usuwania użytkownika")
      }
    } catch (error) {
      console.error("Error deleting user:", error)
      alert("Błąd podczas usuwania użytkownika")
    }
  }

  if (session?.user?.role !== "admin") {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Brak uprawnień do zarządzania użytkownikami</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#2B7CB3]"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-normal text-gray-900">Użytkownicy</h1>
          <p className="text-gray-600">Zarządzaj użytkownikami systemu CMS</p>
        </div>
        <Button onClick={() => setShowAddForm(true)} className="bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
          Dodaj użytkownika
        </Button>
      </div>

      {showAddForm && (
        <Card className="rounded-none">
          <CardHeader>
            <CardTitle className="font-normal">Dodaj nowego użytkownika</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAddUser} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="username">Nazwa użytkownika</Label>
                <Input
                  id="username"
                  value={newUser.username}
                  onChange={(e) => setNewUser((prev) => ({ ...prev, username: e.target.value }))}
                  required
                  className="rounded-none"
                />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newUser.email}
                  onChange={(e) => setNewUser((prev) => ({ ...prev, email: e.target.value }))}
                  required
                  className="rounded-none"
                />
              </div>
              <div>
                <Label htmlFor="password">Hasło</Label>
                <Input
                  id="password"
                  type="password"
                  value={newUser.password}
                  onChange={(e) => setNewUser((prev) => ({ ...prev, password: e.target.value }))}
                  required
                  className="rounded-none"
                />
              </div>
              <div>
                <Label htmlFor="role">Rola</Label>
                <select
                  id="role"
                  value={newUser.role}
                  onChange={(e) => setNewUser((prev) => ({ ...prev, role: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-none bg-white"
                >
                  <option value="editor">Edytor</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>
              <div className="md:col-span-2 flex gap-2">
                <Button type="submit" className="bg-[#2B7CB3] hover:bg-[#1E5A87] rounded-none">
                  Dodaj użytkownika
                </Button>
                <Button type="button" variant="outline" onClick={() => setShowAddForm(false)} className="rounded-none">
                  Anuluj
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <Card className="rounded-none">
        <CardHeader>
          <CardTitle className="font-normal">Lista użytkowników</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                    Użytkownik
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                    Rola
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                    Data utworzenia
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-normal text-gray-500 uppercase tracking-wider">
                    Akcje
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {users.map((user) => (
                  <tr key={user.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-normal text-gray-900">{user.username}</td>
                    <td className="px-6 py-4 text-sm text-gray-900">{user.email}</td>
                    <td className="px-6 py-4">
                      <Badge
                        className={`rounded-none ${user.role === "admin" ? "bg-red-100 text-red-800" : "bg-blue-100 text-blue-800"}`}
                      >
                        {user.role === "admin" ? "Administrator" : "Edytor"}
                      </Badge>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {new Date(user.created_at).toLocaleDateString("pl-PL")}
                    </td>
                    <td className="px-6 py-4 text-sm font-normal">
                      {user.id !== Number(session?.user?.id) && (
                        <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-900">
                          Usuń
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
