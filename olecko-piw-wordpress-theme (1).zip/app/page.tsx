"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PiszPIWWebsite() {
  const [contrastMode, setContrastMode] = useState(false)
  const [textMode, setTextMode] = useState(false)
  const [fontSize, setFontSize] = useState("normal")
  const [showPreviousVersions, setShowPreviousVersions] = useState(false)
  const [showMetadata, setShowMetadata] = useState(false)
  const [selectedMenuItem, setSelectedMenuItem] = useState("Dane podstawowe")

  const [menuItems, setMenuItems] = useState([])
  const [currentArticle, setCurrentArticle] = useState(null)
  const [articleVersions, setArticleVersions] = useState([])
  const [settings, setSettings] = useState({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch menu items
        const menuResponse = await fetch("/api/public/menu")
        const menuData = await menuResponse.json()
        setMenuItems(menuData.menuItems || [])

        // Fetch settings
        const settingsResponse = await fetch("/api/public/settings")
        const settingsData = await settingsResponse.json()
        setSettings(settingsData.settings || {})

        // Fetch latest article for homepage
        const articlesResponse = await fetch("/api/public/articles?limit=1")
        const articlesData = await articlesResponse.json()
        if (articlesData.articles && articlesData.articles.length > 0) {
          const article = articlesData.articles[0]
          setCurrentArticle(article)

          // Fetch article versions
          const articleResponse = await fetch(`/api/public/articles/${article.slug}`)
          const articleData = await articleResponse.json()
          setArticleVersions(articleData.versions || [])
        }

        setLoading(false)
      } catch (error) {
        console.error("Error fetching data:", error)
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const toggleContrast = () => setContrastMode(!contrastMode)
  const toggleTextMode = () => setTextMode(!textMode)
  const adjustFontSize = (size: string) => setFontSize(size)

  const handleMenuItemClick = async (item: string) => {
    setSelectedMenuItem(item)

    // Try to fetch articles for this category
    try {
      const response = await fetch(`/api/public/articles?category=${encodeURIComponent(item)}&limit=1`)
      const data = await response.json()
      if (data.articles && data.articles.length > 0) {
        const article = data.articles[0]
        setCurrentArticle(article)

        // Fetch article versions
        const articleResponse = await fetch(`/api/public/articles/${article.slug}`)
        const articleData = await articleResponse.json()
        setArticleVersions(articleData.versions || [])
      }
    } catch (error) {
      console.error("Error fetching article:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-[#2B7CB3]"></div>
          <p className="mt-4 text-gray-600">Ładowanie...</p>
        </div>
      </div>
    )
  }

  return (
    <div
      className={`min-h-screen px-[50px] ${contrastMode ? "bg-black text-white" : "bg-white text-gray-900"} ${fontSize === "small" ? "text-sm" : fontSize === "large" ? "text-lg" : "text-base"}`}
    >
      {/* Accessibility Bar */}
      <div className={`${contrastMode ? "bg-gray-800" : "bg-gray-100"} border-b px-4 py-2`}>
        <div className="w-full flex flex-wrap items-center justify-between gap-2 text-sm">
          <div className="flex items-center gap-4">
            <button onClick={() => adjustFontSize("small")} className="hover:underline">
              A-
            </button>
            <button onClick={() => adjustFontSize("normal")} className="hover:underline">
              A
            </button>
            <button onClick={() => adjustFontSize("large")} className="hover:underline">
              A+
            </button>
          </div>
          <div className="flex items-center gap-4">
            <button onClick={toggleContrast} className="hover:underline">
              Wersja kontrastowa
            </button>
            <button onClick={toggleTextMode} className="hover:underline">
              Wersja tekstowa
            </button>
            <a href="#deklaracja-dostepnosci" className="hover:underline">
              Deklaracja dostępności
            </a>
            <a href="#slownik-skrotow" className="hover:underline">
              Słownik skrótów
            </a>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className={`${contrastMode ? "bg-white text-black" : "bg-[#2B7CB3] text-white"}`}>
        <div className="w-full px-4 py-6">
          <div className="flex items-center gap-4">
            {!textMode && <img src="/polish-coat-of-arms.png" alt="Herb Polski" className="h-20 w-20" />}
            <div>
              <h1 className="text-2xl font-normal">
                {settings.site_title || "Powiatowy Inspektorat Weterynaryjny w Piszu"}
              </h1>
              <p className={`${contrastMode ? "text-gray-600" : "text-blue-100"}`}>
                {settings.site_subtitle || "Ministerstwo Rolnictwa i Rozwoju Wsi"}
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className={`${contrastMode ? "bg-black text-white" : "bg-[#1E5A87] text-white"}`}>
        <div className="w-full px-4">
          <ul className="flex flex-wrap">
            <li>
              <a href="#" className={`block px-4 py-3 ${contrastMode ? "hover:bg-gray-800" : "hover:bg-[#164A73]"}`}>
                Strona główna
              </a>
            </li>
            <li>
              <a href="#" className={`block px-4 py-3 ${contrastMode ? "hover:bg-gray-800" : "hover:bg-[#164A73]"}`}>
                O nas
              </a>
            </li>
            <li>
              <a href="#" className={`block px-4 py-3 ${contrastMode ? "hover:bg-gray-800" : "hover:bg-[#164A73]"}`}>
                Aktualności
              </a>
            </li>
            <li>
              <a href="#" className={`block px-4 py-3 ${contrastMode ? "hover:bg-gray-800" : "hover:bg-[#164A73]"}`}>
                Usługi
              </a>
            </li>
            <li>
              <a href="#" className={`block px-4 py-3 ${contrastMode ? "hover:bg-gray-800" : "hover:bg-[#164A73]"}`}>
                Kontakt
              </a>
            </li>
          </ul>
        </div>
      </nav>

      {/* Main Content */}
      <main className="w-full px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <Card className={`rounded-none ${contrastMode ? "bg-gray-700 border-gray-600" : ""}`}>
              <CardContent className="p-0">
                <ul className="space-y-0">
                  {menuItems.map((item, index) => (
                    <li key={item.id} className={`border-b ${contrastMode ? "border-gray-600" : "border-gray-200"}`}>
                      <a
                        href="#"
                        className={`block px-4 py-3 ${
                          selectedMenuItem === item.title
                            ? "bg-[#2B7CB3] text-white font-normal border-b-2 border-white"
                            : contrastMode
                              ? "text-white hover:bg-gray-600"
                              : "text-gray-700 hover:bg-gray-50"
                        }`}
                        onClick={() => handleMenuItemClick(item.title)}
                      >
                        {item.title}
                      </a>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <div className="mt-4 space-y-3">
              {/* Civil Service Button */}
              <Card
                className={`rounded-none border-2 ${contrastMode ? "border-gray-600 bg-gray-700" : "border-gray-300"}`}
              >
                <CardContent className="p-3">
                  <a
                    href="https://sluzba-cywilna.gov.pl"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-3 transition-colors ${contrastMode ? "hover:bg-gray-600" : "hover:bg-gray-50"}`}
                  >
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 bg-red-600 flex items-center justify-center text-white font-normal text-xs rounded-none">
                        <div className="text-center">
                          <div className="text-[8px] leading-none">SŁUŻBA</div>
                          <div className="text-[8px] leading-none">CYWILNA</div>
                        </div>
                      </div>
                    </div>
                    <span className={`font-normal ${contrastMode ? "text-white" : "text-gray-800"}`}>
                      Służba Cywilna
                    </span>
                  </a>
                </CardContent>
              </Card>

              {/* BIP.gov.pl Button */}
              <Card
                className={`rounded-none border-2 ${contrastMode ? "border-gray-600 bg-gray-700" : "border-gray-300"}`}
              >
                <CardContent className="p-3">
                  <a
                    href="https://bip.gov.pl"
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center gap-3 transition-colors ${contrastMode ? "hover:bg-gray-600" : "hover:bg-gray-50"}`}
                  >
                    <div className="flex-shrink-0">
                      <div
                        className={`w-12 h-12 border flex items-center justify-center rounded-none ${contrastMode ? "bg-gray-800 border-gray-600" : "bg-white border-gray-300"}`}
                      >
                        <span className="text-red-600 font-normal text-sm">bip</span>
                      </div>
                    </div>
                    <span className={`font-normal ${contrastMode ? "text-white" : "text-gray-800"}`}>bip.gov.pl</span>
                  </a>
                </CardContent>
              </Card>
            </div>
          </aside>

          {/* Article Content */}
          <div className="lg:col-span-4">
            {currentArticle ? (
              <article
                className={`shadow-sm border p-6 rounded-none ${contrastMode ? "bg-gray-800 border-gray-600" : "bg-white"}`}
              >
                <header className="mb-6">
                  <h1 className={`text-2xl font-normal mb-2 ${contrastMode ? "text-yellow-400" : "text-[#1E5A87]"}`}>
                    {currentArticle.title}
                  </h1>
                  <p className={`text-sm ${contrastMode ? "text-gray-300" : "text-gray-600"}`}>
                    Opublikowano: {new Date(currentArticle.created_at).toLocaleDateString("pl-PL")}{" "}
                    {new Date(currentArticle.created_at).toLocaleTimeString("pl-PL", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}{" "}
                    | Ostatnia aktualizacja: {new Date(currentArticle.updated_at).toLocaleDateString("pl-PL")}{" "}
                    {new Date(currentArticle.updated_at).toLocaleTimeString("pl-PL", {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </header>

                <div className="prose max-w-none mb-8">
                  <div
                    className={contrastMode ? "text-white" : ""}
                    dangerouslySetInnerHTML={{ __html: currentArticle.content }}
                  />
                </div>

                {/* Previous Versions Section */}
                {showPreviousVersions && (
                  <Card className={`mb-6 rounded-none ${contrastMode ? "bg-gray-700 border-gray-600" : ""}`}>
                    <CardHeader className="bg-[#2B7CB3] text-white rounded-none">
                      <CardTitle>poprzednie wersje: {currentArticle.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div
                        className={`p-3 text-sm text-center ${contrastMode ? "bg-gray-600 text-white" : "bg-yellow-50"}`}
                      >
                        * każdorazowo możesz wybrać do porównania tylko 2 wersje artykułu
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead className={contrastMode ? "bg-gray-600" : "bg-gray-50"}>
                            <tr>
                              <th className={`px-4 py-2 text-left ${contrastMode ? "text-white" : ""}`}>
                                Data aktualizacji
                              </th>
                              <th className={`px-4 py-2 text-left ${contrastMode ? "text-white" : ""}`}>
                                Zaktualizował
                              </th>
                              <th className={`px-4 py-2 text-left ${contrastMode ? "text-white" : ""}`}>
                                Podgląd treści
                              </th>
                              <th className={`px-4 py-2 text-left ${contrastMode ? "text-white" : ""}`}>Porównaj</th>
                            </tr>
                          </thead>
                          <tbody>
                            {articleVersions.map((version, index) => (
                              <tr key={version.id} className={`border-b ${contrastMode ? "border-gray-600" : ""}`}>
                                <td className={`px-4 py-2 ${contrastMode ? "text-white" : ""}`}>
                                  {new Date(version.created_at).toLocaleDateString("pl-PL")}{" "}
                                  {new Date(version.created_at).toLocaleTimeString("pl-PL", {
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })}
                                </td>
                                <td className={`px-4 py-2 ${contrastMode ? "text-white" : ""}`}>
                                  {version.updated_by_name}
                                </td>
                                <td className="px-4 py-2">
                                  <button className="text-[#2B7CB3] hover:text-[#1E5A87]">
                                    <svg
                                      width="16"
                                      height="16"
                                      viewBox="0 0 24 24"
                                      fill="currentColor"
                                      className="inline-block"
                                    >
                                      <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5S13.09 3 9.5 3S14 5.91 14 9.5 11.99 14 9.5 14c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z" />
                                    </svg>
                                  </button>
                                </td>
                                <td className="px-4 py-2">
                                  <input type="checkbox" className="rounded" />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Metadata Section */}
                {showMetadata && (
                  <Card className={`mb-6 rounded-none ${contrastMode ? "bg-gray-700 border-gray-600" : ""}`}>
                    <CardContent className="p-4">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>
                              Odpowiedzialny za treść:
                            </span>
                            <span className={contrastMode ? "text-white" : ""}>{currentArticle.author_name}</span>
                          </div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>Data wytworzenia:</span>
                            <span className={contrastMode ? "text-white" : ""}>
                              {new Date(currentArticle.created_at).toLocaleDateString("pl-PL")}
                            </span>
                          </div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>
                              Data opublikowania:
                            </span>
                            <span className={contrastMode ? "text-white" : ""}>
                              {new Date(currentArticle.created_at).toLocaleDateString("pl-PL")}{" "}
                              {new Date(currentArticle.created_at).toLocaleTimeString("pl-PL", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                        </div>
                        <div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>
                              Ostatnio zaktualizował:
                            </span>
                            <span className={contrastMode ? "text-white" : ""}>
                              {currentArticle.updated_by_name || currentArticle.author_name}
                            </span>
                          </div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>
                              Data ostatniej aktualizacji:
                            </span>
                            <span className={contrastMode ? "text-white" : ""}>
                              {new Date(currentArticle.updated_at).toLocaleDateString("pl-PL")}{" "}
                              {new Date(currentArticle.updated_at).toLocaleTimeString("pl-PL", {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </span>
                          </div>
                          <div
                            className={`flex justify-between py-1 border-b ${contrastMode ? "border-gray-600" : ""}`}
                          >
                            <span className={`font-normal ${contrastMode ? "text-white" : ""}`}>
                              Liczba wyświetleń:
                            </span>
                            <span className="text-blue-600">{currentArticle.view_count}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Action Buttons */}
                <div
                  className={`text-white p-3 flex flex-wrap items-center justify-between gap-2 ${contrastMode ? "bg-gray-900" : "bg-[#2B7CB3]"}`}
                >
                  <div className="flex gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="bg-[#1E5A87] hover:bg-[#164A73] text-white rounded-none flex items-center gap-2"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                      </svg>
                      Drukuj
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      className="bg-[#1E5A87] hover:bg-[#164A73] text-white rounded-none flex items-center gap-2"
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z" />
                      </svg>
                      Zapisz do PDF
                    </Button>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="secondary"
                      size="sm"
                      className="bg-[#1E5A87] hover:bg-[#164A73] text-white rounded-none flex items-center gap-2"
                      onClick={() => setShowPreviousVersions(!showPreviousVersions)}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M13,3A9,9 0 0,0 4,12H1L4.89,15.89L4.96,16.03L9,12H6A7,7 0 0,1 13,5A7,7 0 0,1 20,12A7,7 0 0,1 13,19C11.07,19 9.32,18.21 8.06,16.94L6.64,18.36C8.27,20 10.5,21 13,21A9,9 0 0,0 22,12A9,9 0 0,0 13,3Z" />
                      </svg>
                      poprzednie wersje
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      className="bg-[#4A90B8] hover:bg-[#3A7FA8] text-white rounded-none flex items-center gap-2"
                      onClick={() => setShowMetadata(!showMetadata)}
                    >
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z" />
                      </svg>
                      metryczka
                    </Button>
                  </div>
                </div>
              </article>
            ) : (
              <div
                className={`shadow-sm border p-6 rounded-none text-center ${contrastMode ? "bg-gray-800 border-gray-600" : "bg-white"}`}
              >
                <p className={contrastMode ? "text-white" : "text-gray-600"}>Brak artykułów do wyświetlenia.</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className={`${contrastMode ? "bg-gray-900 text-white" : "bg-[#1E5A87] text-white"} mt-12`}>
        <div className="w-full px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-normal mb-4">Kontakt</h3>
              <p>{settings.contact_name || "Powiatowy Inspektorat Weterynaryjny w Piszu"}</p>
              <p>{settings.contact_address || "ul. Przykładowa 1"}</p>
              <p>{settings.contact_city || "19-400 Pisz"}</p>
              <p>Tel: {settings.contact_phone || "+48 87 520 XX XX"}</p>
            </div>
            <div>
              <h3 className="font-normal mb-4">Godziny pracy</h3>
              <p>{settings.office_hours || "Poniedziałek - Piątek: 7:30 - 15:30"}</p>
              <p>{settings.office_hours_weekend || "Sobota - Niedziela: Nieczynne"}</p>
            </div>
            <div>
              <h3 className="font-normal mb-4">Przydatne linki</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="hover:underline">
                    Ministerstwo Rolnictwa
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    Główny Inspektorat Weterynarii
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:underline">
                    BIP
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
