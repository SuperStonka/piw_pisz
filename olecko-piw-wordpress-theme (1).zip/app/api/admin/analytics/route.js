import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import db from "@/lib/database"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get article statistics
    const articleStats = db
      .prepare(`
      SELECT 
        COUNT(*) as total_articles,
        COUNT(CASE WHEN status = 'published' THEN 1 END) as published_articles,
        COUNT(CASE WHEN status = 'draft' THEN 1 END) as draft_articles,
        SUM(view_count) as total_views,
        AVG(view_count) as avg_views
      FROM articles
    `)
      .get()

    // Get most viewed articles
    const mostViewed = db
      .prepare(`
      SELECT title, slug, view_count, updated_at
      FROM articles 
      WHERE status = 'published'
      ORDER BY view_count DESC 
      LIMIT 10
    `)
      .all()

    // Get recent articles
    const recentArticles = db
      .prepare(`
      SELECT a.title, a.slug, a.status, a.created_at, u.username as author_name
      FROM articles a
      LEFT JOIN users u ON a.created_by = u.id
      ORDER BY a.created_at DESC 
      LIMIT 10
    `)
      .all()

    // Get articles by category
    const categoryStats = db
      .prepare(`
      SELECT 
        menu_category,
        COUNT(*) as count,
        SUM(view_count) as total_views
      FROM articles 
      WHERE menu_category IS NOT NULL AND menu_category != ''
      GROUP BY menu_category
      ORDER BY count DESC
    `)
      .all()

    // Get monthly article creation stats
    const monthlyStats = db
      .prepare(`
      SELECT 
        strftime('%Y-%m', created_at) as month,
        COUNT(*) as articles_created,
        COUNT(CASE WHEN status = 'published' THEN 1 END) as articles_published
      FROM articles 
      WHERE created_at >= date('now', '-12 months')
      GROUP BY strftime('%Y-%m', created_at)
      ORDER BY month DESC
    `)
      .all()

    // Get user activity stats
    const userStats = db
      .prepare(`
      SELECT 
        u.username,
        COUNT(a.id) as articles_created,
        SUM(a.view_count) as total_views,
        MAX(a.updated_at) as last_activity
      FROM users u
      LEFT JOIN articles a ON u.id = a.created_by
      GROUP BY u.id, u.username
      ORDER BY articles_created DESC
    `)
      .all()

    return NextResponse.json({
      articleStats,
      mostViewed,
      recentArticles,
      categoryStats,
      monthlyStats,
      userStats,
    })
  } catch (error) {
    console.error("Error fetching analytics:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
