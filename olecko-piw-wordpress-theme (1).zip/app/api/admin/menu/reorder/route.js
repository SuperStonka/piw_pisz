import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { MenuItem } from "@/lib/models/MenuItem"

export async function PUT(request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const items = await request.json()

    // Update sort order for all items
    MenuItem.updateSortOrder(items)

    return NextResponse.json({ message: "Menu order updated successfully" })
  } catch (error) {
    console.error("Error updating menu order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
