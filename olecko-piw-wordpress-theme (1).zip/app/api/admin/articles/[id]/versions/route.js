import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { Article } from "@/lib/models/Article"

export async function GET(request, { params }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const versions = Article.getVersions(params.id)
    return NextResponse.json(versions)
  } catch (error) {
    console.error("Error fetching article versions:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
