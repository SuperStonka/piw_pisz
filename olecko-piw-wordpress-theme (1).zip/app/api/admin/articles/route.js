import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import { Article } from "@/lib/models/Article"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const articles = Article.getAll()
    return NextResponse.json(articles)
  } catch (error) {
    console.error("Error fetching articles:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const data = await request.json()
    const articleId = Article.create({
      ...data,
      created_by: Number.parseInt(session.user.id),
    })

    return NextResponse.json({ id: articleId, message: "Article created successfully" })
  } catch (error) {
    console.error("Error creating article:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
