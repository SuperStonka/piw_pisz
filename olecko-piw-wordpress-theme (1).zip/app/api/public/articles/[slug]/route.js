import { db } from "@/lib/database"

export async function GET(request, { params }) {
  try {
    const { slug } = params

    // Get article with author info
    const article = db
      .prepare(`
      SELECT a.*, u.name as author_name, u2.name as updated_by_name
      FROM articles a 
      LEFT JOIN users u ON a.created_by = u.id 
      LEFT JOIN users u2 ON a.updated_by = u2.id
      WHERE a.slug = ? AND a.status = 'published'
    `)
      .get(slug)

    if (!article) {
      return Response.json({ error: "Article not found" }, { status: 404 })
    }

    // Increment view count
    db.prepare("UPDATE articles SET view_count = view_count + 1 WHERE id = ?").run(article.id)
    article.view_count += 1

    // Get article versions for poprzednie wersje
    const versions = db
      .prepare(`
      SELECT av.*, u.name as updated_by_name
      FROM article_versions av
      LEFT JOIN users u ON av.updated_by = u.id
      WHERE av.article_id = ?
      ORDER BY av.created_at DESC
    `)
      .all(article.id)

    return Response.json({ article, versions })
  } catch (error) {
    console.error("Error fetching article:", error)
    return Response.json({ error: "Failed to fetch article" }, { status: 500 })
  }
}
