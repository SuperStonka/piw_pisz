import { db } from "@/lib/database"

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get("category")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    let query = `
      SELECT a.*, u.name as author_name 
      FROM articles a 
      LEFT JOIN users u ON a.created_by = u.id 
      WHERE a.status = 'published'
    `
    const params = []

    if (category) {
      query += " AND a.category = ?"
      params.push(category)
    }

    query += " ORDER BY a.created_at DESC LIMIT ?"
    params.push(limit)

    const articles = db.prepare(query).all(...params)

    return Response.json({ articles })
  } catch (error) {
    console.error("Error fetching articles:", error)
    return Response.json({ error: "Failed to fetch articles" }, { status: 500 })
  }
}
