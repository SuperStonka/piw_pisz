import { db } from "@/lib/database"

export async function GET() {
  try {
    const menuItems = db
      .prepare(`
      SELECT * FROM menu_items 
      WHERE is_active = 1 
      ORDER BY sort_order ASC
    `)
      .all()

    return Response.json({ menuItems })
  } catch (error) {
    console.error("Error fetching menu:", error)
    return Response.json({ error: "Failed to fetch menu" }, { status: 500 })
  }
}
