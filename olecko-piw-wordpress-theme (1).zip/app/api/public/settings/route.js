import { db } from "@/lib/database"

export async function GET() {
  try {
    const settings = {}
    const rows = db.prepare("SELECT key, value FROM site_settings").all()

    rows.forEach((row) => {
      settings[row.key] = row.value
    })

    return Response.json({ settings })
  } catch (error) {
    console.error("Error fetching settings:", error)
    return Response.json({ error: "Failed to fetch settings" }, { status: 500 })
  }
}
